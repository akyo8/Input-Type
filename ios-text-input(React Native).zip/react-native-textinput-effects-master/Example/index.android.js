import React, {
  AppRegistry,
} from 'react-native';

import TextInputEffectsExample from './TextInputEffectsExample';

AppRegistry.registerComponent('TextInputEffects', () => TextInputEffectsExample);
